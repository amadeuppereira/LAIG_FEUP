/**
 * MyAnimation
 * @constructor
 */
class MyAnimation {

    /**
     * @constructor
     */
    constructor(scene, id, time) {
        this.scene = scene;
        this.id = id;
        this.time = time;
    }

    update(){}

    apply(){}
}